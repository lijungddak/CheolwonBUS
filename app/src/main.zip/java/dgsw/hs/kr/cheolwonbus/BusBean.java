package dgsw.hs.kr.cheolwonbus;

import java.util.ArrayList;

public class BusBean {
    private int sequenceNumber;
    private String routeId;
    private String startStation;
    private String firstViaStation;
    private String returnStation;
    private String secondViaStation;
    private String endStation;
    private String remainTime;
    private String nextTime;
    private String route;
    private String type;
    private ArrayList<String> times = new ArrayList<>();

    public BusBean(String routeId, String startStation, String firstViaStation, String returnStation, String secondViaStation, String endStation, String route, String type) {
        this.routeId = routeId;
        this.startStation = startStation;
        this.firstViaStation = firstViaStation;
        this.returnStation = returnStation;
        this.secondViaStation = secondViaStation;
        this.endStation = endStation;
        this.route = route;
        this.type = type;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getStartStation() {
        return startStation;
    }

    public void setStartStation(String startStation) {
        this.startStation = startStation;
    }

    public String getFirstViaStation() {
        return firstViaStation;
    }

    public void setFirstViaStation(String firstViaStation) {
        this.firstViaStation = firstViaStation;
    }

    public String getReturnStation() {
        return returnStation;
    }

    public void setReturnStation(String returnStation) {
        this.returnStation = returnStation;
    }

    public String getSecondViaStation() {
        return secondViaStation;
    }

    public void setSecondViaStation(String secondViaStation) {
        this.secondViaStation = secondViaStation;
    }

    public String getEndStation() {
        return endStation;
    }

    public void setEndStation(String endStation) {
        this.endStation = endStation;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ArrayList<String> getTimes() {
        return times;
    }

    public void setTimes(ArrayList<String> times) {
        this.times = times;
    }

    public String getRemainTime() {
        return remainTime;
    }

    public void setRemainTime(String remainTime) {
        this.remainTime = remainTime;
    }

    public String getNextTime() {
        return nextTime;
    }

    public void setNextTime(String nextTime) {
        this.nextTime = nextTime;
    }
}

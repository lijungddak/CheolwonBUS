package dgsw.hs.kr.cheolwonbus;

import android.view.View;

public interface ItemClickListener {
    public void onItemClick(View v, int position);
}

package dgsw.hs.kr.cheolwonbus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class item_busInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_bus_info);
    }
}

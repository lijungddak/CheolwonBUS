package dgsw.hs.kr.cheolwonbus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class SearchStop extends AppCompatActivity implements ItemClickListener {

    private EditText editText;
    private RecyclerView busList;
    private BusAdapter adapter;
    private ArrayList<BusBean> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_stop);

        editText = findViewById(R.id.etBusStop);
        busList = findViewById(R.id.busList);

        try {
            data= new Description().execute().get();
            adapter = new BusAdapter(data, this);
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        busList.setLayoutManager(layoutManager);
        busList.setAdapter(adapter);
    }

    public void SearchBusStop(View v){
        String busStop = editText.getText().toString().trim();

        if(busStop == null || busStop.equals("")){
            adapter.changedData(data);
            adapter.notifyDataSetChanged();
            return;
        }

        ArrayList<BusBean> searchData = new ArrayList<>();
        for(BusBean busBean : data){
            if(busBean.getRoute().matches(".*" +busStop + ".*") || busBean.getStartStation().equals(busStop)
                    || busBean.getFirstViaStation().equals(busStop) || busBean.getReturnStation().equals(busStop)
                    || busBean.getSecondViaStation().equals(busStop) || busBean.getEndStation().equals(busStop)){
                searchData.add(busBean);
            }
        }

        adapter.changedData(searchData);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(View v, int position) {

    }
}
